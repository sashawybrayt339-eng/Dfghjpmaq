extends Control

var room_edit: LineEdit
var status: Label

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)

	var bg := ColorRect.new()
	bg.color = Color(0.08, 0.09, 0.12)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 28)
	add_child(box)

	var title := Label.new()
	title.text = "RACE MULTIPLAYER"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 48)
	box.add_child(title)

	room_edit = LineEdit.new()
	room_edit.placeholder_text = "Room code, e.g. 1"
	room_edit.text = "1"
	room_edit.custom_minimum_size = Vector2(420, 90)
	box.add_child(room_edit)

	var play_btn := Button.new()
	play_btn.text = "PLAY  (HOST / JOIN)"
	play_btn.custom_minimum_size = Vector2(420, 120)
	play_btn.add_theme_font_size_override("font_size", 36)
	play_btn.pressed.connect(func(): Net.start(room_edit.text))
	box.add_child(play_btn)

	status = Label.new()
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(status)

	Net.message.connect(_on_message)
	_on_message(Net.last_message)

func _on_message(t: String) -> void:
	status.text = t
