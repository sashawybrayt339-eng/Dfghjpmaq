extends Node

# Photon Fusion connection (autoload "Net"). No IP needed: everyone joins the same room name.

signal message(text: String)

const APP_ID := "69721bc0-f07d-4f9b-b9e7-43d985a7ca74"
const APP_VERSION := "1.0"
const REGION := "eu"
const LOADING_SCENE := "res://scenes/loading.tscn"
const MAX_PLAYERS := 8

var pending_room := ""
var is_connected := false
var last_message := ""

func _ready() -> void:
	Fusion.set_app_id(APP_ID)
	Fusion.connected_to_photon.connect(_on_connected)
	Fusion.room_joined.connect(_on_room_joined)
	Fusion.connection_failed.connect(_on_connection_failed)

func start(room_code: String) -> void:
	pending_room = room_code.strip_edges()
	if pending_room == "":
		_set_message("Enter a room code")
		return
	_set_message("Connecting...")
	if is_connected:
		_join_room()
	else:
		Fusion.connect_to_photon("player_%d" % randi(), REGION, APP_VERSION)

func _on_connected() -> void:
	is_connected = true
	_join_room()

func _join_room() -> void:
	Fusion.join_or_create_room(pending_room, {"max_players": MAX_PLAYERS})

func _on_room_joined() -> void:
	_set_message("")
	get_tree().change_scene_to_file(LOADING_SCENE)

func _on_connection_failed(reason: String) -> void:
	is_connected = false
	_set_message("Connection failed: " + reason)

func _set_message(t: String) -> void:
	last_message = t
	message.emit(t)
