extends Control

const RACE_PATH := "res://scenes/race.tscn"

var bar: ProgressBar
var label: Label

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)

	var bg := ColorRect.new()
	bg.color = Color(0.05, 0.05, 0.07)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 30)
	add_child(box)

	label = Label.new()
	label.text = "LOADING..."
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 44)
	box.add_child(label)

	bar = ProgressBar.new()
	bar.custom_minimum_size = Vector2(600, 40)
	bar.max_value = 100.0
	box.add_child(bar)

	ResourceLoader.load_threaded_request(RACE_PATH)

func _process(_delta: float) -> void:
	var progress: Array = []
	var status := ResourceLoader.load_threaded_get_status(RACE_PATH, progress)
	if progress.size() > 0:
		bar.value = float(progress[0]) * 100.0
	if status == ResourceLoader.THREAD_LOAD_LOADED:
		set_process(false)
		get_tree().change_scene_to_packed(ResourceLoader.load_threaded_get(RACE_PATH))
	elif status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
		set_process(false)
		label.text = "LOAD FAILED"
