extends Node3D

# Race map. Players are spawned through FusionSpawner; each client owns its own player.

const TRACK_R := 40.0
const TRACK_W := 14.0
const SEGMENTS := 48
const LAPS := 3
const CP_COUNT := 4
const PLAYER_SCENE := preload("res://scenes/player.tscn")

var countdown := 0.0
var go_timer := 0.0
var clock := 0.0
var clock_on := false
var my_expected := 1
var my_lap := 0
var my_finished := false
var local_player: CharacterBody3D = null

var players: Node3D
var spawner: FusionSpawner
var hud_layer: CanvasLayer
var overlay: Control
var lap_label: Label
var time_label: Label
var center_label: Label

func _ready() -> void:
	_setup_world()
	_build_track()
	_build_checkpoints()
	_build_hud()

	players = Node3D.new()
	players.name = "Players"
	add_child(players)

	spawner = FusionSpawner.new()
	spawner.name = "Spawner"
	add_child(spawner)
	spawner.spawn_path = players.get_path()
	spawner.add_spawnable_scene(PLAYER_SCENE)

	Net.on_race_ready(self)

func spawn_local_player() -> void:
	# Creates the player on every client in the room. The copy returned here is ours.
	local_player = spawner.spawn(PLAYER_SCENE, _setup_replicator) as CharacterBody3D
	if local_player:
		local_player.is_mine = true
	countdown = 3.0

# Tell Fusion which properties of the player to sync (position and rotation, plus head tilt).
func _setup_replicator(replicator: Node, _root: Node) -> void:
	var rc := SceneReplicationConfig.new()
	rc.add_property(NodePath(".:position"))
	rc.add_property(NodePath(".:rotation"))
	rc.add_property(NodePath("Head:rotation"))
	replicator.replication_config = rc

func _process(delta: float) -> void:
	if countdown > 0.0:
		countdown -= delta
		if countdown > 0.0:
			center_label.text = str(ceili(countdown))
		else:
			center_label.text = "GO!"
			go_timer = 0.8
			clock_on = true
			if local_player:
				local_player.can_move = true
	elif go_timer > 0.0:
		go_timer -= delta
		if go_timer <= 0.0 and not my_finished:
			center_label.text = ""

	if clock_on:
		clock += delta
	lap_label.text = "LAP %d / %d" % [mini(my_lap + 1, LAPS), LAPS]
	time_label.text = "%.2f s" % clock
	overlay.queue_redraw()

func _on_checkpoint(body: Node3D, idx: int) -> void:
	if body != local_player:
		return
	if not clock_on or my_finished or idx != my_expected:
		return
	my_expected = (idx + 1) % CP_COUNT
	if idx == 0:
		my_lap += 1
		if my_lap >= LAPS:
			_finish()

func _finish() -> void:
	my_finished = true
	clock_on = false
	go_timer = 0.0
	if local_player:
		local_player.can_move = false
	center_label.text = "Finished: %.2f s" % clock

func _setup_world() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.55, 0.78, 1.0)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.85, 0.85)
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, 30, 0)
	add_child(sun)

func _build_track() -> void:
	_add_box(Vector3(0, -0.5, 0), Vector3(800, 1, 800), 0.0, Color(0.25, 0.55, 0.25))
	var step := TAU / SEGMENTS
	var seg_len := 2.0 * PI * TRACK_R / SEGMENTS + 0.3
	var inner := TRACK_R - TRACK_W * 0.5 - 0.5
	var outer := TRACK_R + TRACK_W * 0.5 + 0.5
	for i in SEGMENTS:
		var a := (i + 0.5) * step
		var dir := Vector3(cos(a), 0, sin(a))
		_add_box(dir * TRACK_R + Vector3(0, 0.1, 0), Vector3(TRACK_W, 0.2, seg_len), -a, Color(0.2, 0.2, 0.23))
		_add_box(Vector3(cos(a) * inner, 1.0, sin(a) * inner), Vector3(1, 2, seg_len), -a, Color(0.85, 0.2, 0.2))
		_add_box(Vector3(cos(a) * outer, 1.0, sin(a) * outer), Vector3(1, 2, seg_len), -a, Color(0.85, 0.2, 0.2))

func _build_checkpoints() -> void:
	for i in CP_COUNT:
		var a := i * TAU / CP_COUNT
		var area := Area3D.new()
		area.position = Vector3(cos(a) * TRACK_R, 2.0, sin(a) * TRACK_R)
		area.rotation.y = -a

		var col := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = Vector3(TRACK_W, 4.0, 1.0)
		col.shape = shape
		area.add_child(col)

		var mi := MeshInstance3D.new()
		var mesh := BoxMesh.new()
		mesh.size = Vector3(TRACK_W, 4.0, 0.3)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(1, 0.9, 0.2, 0.35) if i == 0 else Color(1, 1, 1, 0.25)
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mesh.material = mat
		mi.mesh = mesh
		area.add_child(mi)

		area.body_entered.connect(_on_checkpoint.bind(i))
		add_child(area)

func _add_box(pos: Vector3, size: Vector3, rot_y: float, color: Color) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation.y = rot_y
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mesh.material = mat
	mi.mesh = mesh
	body.add_child(mi)
	add_child(body)

func _build_hud() -> void:
	hud_layer = CanvasLayer.new()
	add_child(hud_layer)

	overlay = Control.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.draw.connect(_draw_overlay)
	hud_layer.add_child(overlay)

	lap_label = _make_label(36)
	lap_label.position = Vector2(24, 20)
	time_label = _make_label(36)
	time_label.position = Vector2(24, 70)

	center_label = _make_label(96)
	center_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	center_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

func _make_label(size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_layer.add_child(l)
	return l

func _draw_overlay() -> void:
	if local_player == null:
		return
	var me := local_player
	if me.move_touch_active:
		overlay.draw_circle(me.joy_origin, me.JOY_RADIUS, Color(1, 1, 1, 0.15))
		overlay.draw_circle(me.joy_origin + me.move_vec * me.JOY_RADIUS, 40.0, Color(1, 1, 1, 0.5))
	overlay.draw_rect(me.jump_rect(), Color(1, 1, 1, 0.2), true)
