extends CharacterBody3D

# First-person player with touch controls.
# Left half: joystick. Right half: drag to look. Bottom-right: jump.
# Position is replicated by Fusion. is_mine is set by race.gd on the local copy.

const WALK_SPEED := 9.0
const JUMP_VELOCITY := 6.5
const GRAVITY := 20.0
const LOOK_SENS := 0.006
const JOY_RADIUS := 90.0
const TRACK_R := 40.0

var is_mine := false
var can_move := false

var move_vec := Vector2.ZERO
var move_touch := -1
var move_touch_active := false
var joy_origin := Vector2.ZERO
var look_touch := -1
var jump_pressed := false
var pitch := 0.0

var head: Node3D
var camera: Camera3D

func _ready() -> void:
	var slot := abs(get_instance_id()) % 6
	var a := -0.12 - float(slot / 2) * 0.13
	var r := TRACK_R + (3.0 if slot % 2 == 0 else -3.0)
	position = Vector3(cos(a) * r, 0.3, sin(a) * r)
	rotation.y = a + PI

	head = Node3D.new()
	head.position = Vector3(0, 1.6, 0)
	add_child(head)

	camera = Camera3D.new()
	head.add_child(camera)

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	col.shape = cap
	col.position.y = 0.9
	add_child(col)

	var body := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.35
	cm.height = 1.8
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color.from_hsv(randf(), 0.8, 1.0)
	cm.material = mat
	body.mesh = cm
	body.position.y = 0.9
	body.visible = false
	add_child(body)
	_apply_mine.call_deferred()

func _apply_mine() -> void:
	# Remote players show a body; the local player sees through their own eyes.
	camera.current = is_mine
	for c in get_children():
		if c is MeshInstance3D:
			c.visible = not is_mine

func _input(event: InputEvent) -> void:
	if not is_mine:
		return
	var vp := get_viewport().get_visible_rect().size

	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			if t.position.x < vp.x * 0.5 and move_touch == -1:
				move_touch = t.index
				joy_origin = t.position
				move_touch_active = true
				move_vec = Vector2.ZERO
			elif jump_rect().has_point(t.position):
				jump_pressed = true
			elif look_touch == -1:
				look_touch = t.index
		else:
			if t.index == move_touch:
				move_touch = -1
				move_touch_active = false
				move_vec = Vector2.ZERO
			if t.index == look_touch:
				look_touch = -1

	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == move_touch:
			var v := (d.position - joy_origin) / JOY_RADIUS
			if v.length() > 1.0:
				v = v.normalized()
			move_vec = v
		elif d.index == look_touch:
			rotate_y(-d.relative.x * LOOK_SENS)
			pitch = clampf(pitch - d.relative.y * LOOK_SENS, -1.4, 1.4)
			head.rotation.x = pitch

func _physics_process(delta: float) -> void:
	if not is_mine:
		return
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	if can_move and jump_pressed and is_on_floor():
		velocity.y = JUMP_VELOCITY
	jump_pressed = false

	var dir := Vector3.ZERO
	if can_move:
		dir = transform.basis * Vector3(move_vec.x, 0, move_vec.y)
	velocity.x = dir.x * WALK_SPEED
	velocity.z = dir.z * WALK_SPEED
	move_and_slide()

func jump_rect() -> Rect2:
	var vp := get_viewport().get_visible_rect().size
	return Rect2(vp.x - 230, vp.y - 230, 190, 190)
