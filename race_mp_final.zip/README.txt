RACE MP - Godot 4.6 SDK + Godot 4.7 project, Photon Fusion networking

BUILD (no PC needed)
1. Upload this whole folder to a GitHub repository.
2. Actions tab > build-apk > Run workflow.
3. Download race-mp-apk from the run's Artifacts and install it.

PLAY
- Everyone types the same room code (default "1") and presses PLAY.
- Controls: left drag = move, right drag = look, bottom-right = jump.
- Race: 3 laps, pass the yellow start gate and white checkpoints in order.

NOTES
- Only the Android arm64 Fusion libraries are included to keep the upload small.
- The App ID is set in code (scripts/net.gd).
- Countdown and finish time are local for now.
